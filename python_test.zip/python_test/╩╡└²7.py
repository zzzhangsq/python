#usr/bin/python
#_*_ coding:utf-8 _*_
import copy
# 实例7：将一个列表的值复制给另一个空列表
#方法一：使用for循环拷贝
# f=[1,2,3]
# e=[]
# # print len(f)
# for i in range(len(f)):
#     e.append(f[i])
# print e
#方法二：调用copy模块
#py2用法
# f=[1,2,3]
# e=copy.copy(f)
# print e
#py3用法
# f=[1,2,3]
# e=f.copy()
# print e
#方法三：使用列表生成式
# f=[1,2,3]
# e=f[:3]
# print e
#方法四：使用迭代方法
f=[1,2,3]
e=[i for i in f]
print e
