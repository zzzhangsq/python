#usr/bin/python
#_*_coding:utf-8_*_
import time
import copy
seq=['name','age','sex','hopy']
d=dict.fromkeys(seq,10)
print d
a=2
d1={(2,3):1}
print "字典为：",{2:1,1:a}
print "元祖为：",(1,{1:1}),({1:1,2:2},[1,2],a)
print "列表为：",[(1,2),{1:2},a]


