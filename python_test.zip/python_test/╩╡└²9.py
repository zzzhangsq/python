#usr/bin/python
#_*_coding:utf-8_*_
import time
d={1:'a',2:'b',3:'c',4:'d'}
for key,value in dict.items(d):
    print key,value
    time.sleep(2)