#usr/bin/python
#_*_ coding:utf-8_*_
#自编码实现斐波那契数列
# def f(n):
#     f=[0,1]
#     if n>1:
#         for i in range(n):
#             x=f[i]+f[i+1]
#             f.append(x)
#     return f[n]
#实例6程序源代码
def fib(n):
    a,b = 0,1
    for i in range(n):
        a,b = b,a+b
    return a

if __name__=='__main__':
    print fib(3)

