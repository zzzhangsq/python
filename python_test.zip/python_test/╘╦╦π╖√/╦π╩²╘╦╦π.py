#usr/bin/python
#_*_coding:utf-8_*_
a=10;b=20
print 'a=',a,'b=',b
a,b=b,a+b
# a=b;b=a
print 'a=',a,'b=',b