#usr/bin/python
#_*_ coding:utf-8 _*_
#99乘法口诀表自编码：把两个因子分别装进两个列表，利用for循环嵌套实现两个因子相乘，然后把得数放进一个列表，利用del语句实现每一行输出一次
# for i in range(1,10):
#     for j in range(1,10):
#         if i<=j:
#             print i, "x", j,"=",i*j
#     print " "
# 方法二：
for i in range(1,10):
    for j in range(1,10):
        print j, "x", i, "=", i * j
        if i==j:
            print('')
            break


