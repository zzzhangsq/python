#usr/bin/python
#_*_coding:utf-8_*_
import copy
d1={1:1}
b=2
d2={1:b,2:'c','c':('c','c')}
d3={1:(1,2,3),2:'b',3:'c'}
d4={1:[1,2,3],2:'b',3:'c',4:'d'}
d5={1:{'jian':'jianzhi'},2:'b',3:'c',4:'d',5:'e'}
#1、str(a)将a的类型转为字符串类型
print type(d2)
str_b=str(d2)
print "str(a)将a的类型转化为字符串:",type(str_b)
#2、cmp(d1,d2)，将字典d1和d2的值进行比较:
#类型：数值number、变量、字符串、元组、列表、字典(元组>字符串>字典>列表>数值)
print cmp([0,1],0)
print cmp({0,1},0)
#3、len(d)返回字典d的长度,即字典键的个数
print "len(d)输出字典的长度：",len(d1),len(d2),len(d3),len(d4),len(d5)
#4、type(b)：返回变量b的类型
b1=1;b2=1.0;b3=1L;b4='a';b5=(1,2);b6={1:2};b7=[1,2];b8=True
print "type(b)返回变量b的类型：",type(b1),type(b2),type(b3),type(b4),type(b5),type(b6),type(b7),type(b8)
#5、d.clear()清空字典的元素
print "d1=",d1
d1.clear()
print "清空后的d1=",d1
# 6、删除字典d1：del d1
# print "删除后输出d1会报如下错误哦",d1
#7、d1=d.copy()d1浅拷贝d，分别是2个对象，但是指向同一个引用，一个变，另一个也随之改变；注意：1、直接赋值、浅复制、深复制的区别：直接赋值是原字典的引用，原字典改变任何值，拷贝后的值都将随之改变；浅复制当且仅当子对象改变的时候才会随之改变；深复制不随原字典改变，不管是父对象还是子对象
# print "d2=",d2
# print "输出d2的浅复制：",d2.copy()
# d2={1:11,2:'cc',3:'d'}
# d2[1]=11;d2[2]='cc';d2[3]='dd'
# print "输出d2的浅复制：",d2.copy()
# d22=d2.copy()
# d22[1]=1
# print "d22改变后的d2=",d2
# print "d22=",d22
# d2[1]=11
# d22=d2.copy()
#
# print "d2=",d2
# print "d2改变后的d22=",d22
#直接赋值
d221=d2
#浅拷贝
d222=d2.copy()
#深拷贝
d223=copy.deepcopy(d2)
print "输出d2改变前的各种拷贝值","d221=",d221,"d222=",d222,"d223=",d223
# d2={1:'a',2:'c','c':('cc','cc')}
d2[1]='a';d2['c']=('cc','cc')
print "输出d2改变后的各种拷贝值","d221=",d221,"d222=",d222,"d223=",d223

#改变子对象(子对象即键值为元组、列表、字典等类型被当做一个对象改变)
# d[2].append(2)
e={1:1,2:(2),3:[3]}
e1=e.copy()
e2=copy.deepcopy(e)
print e,e1,e2
e[3].insert(1,1)
del e[3][0]
#改变父对象
# e={1:1,2:[2,2],3:3,4:4}
# e[2]=[2,2,2]
print e,e1,e2
#8、dict.get(key,default=none)返回key的键值，如果键值不存在，则返回default的值,如none;思考：设置default，会报错？ 解答：不需要带default=，直接写default的值
print d1
print "返回已存在的键值：",d1.get('name',0)
print "返回不存在键的默认值：",d1.get('namea',0)
# print d1.get('name',default=0)  【注意：运行会报错，应去掉default=】
#9、dict.has_key(key)，判断key是否在字典中，存在则返回true   不存在则返回false
print "name是否在字典中：",d1.has_key('name')
print "1是否在字典中：",d1.has_key(1)
print "1是否在字典中：",d1.has_key('1')
print "$否在字典中：",d1.has_key('$')
print "空格是否在字典中：",d1.has_key('')
#10、dict.items()，以列表的方式返回键值元组组合
print "返回d1的键值组合：",d1.items()
#dict.keys()以列表返回一个字典所有的键
print "返回字典d1所有的键：",d1.keys()
#11、dict.setdefault(key,default=00),设置该键值，该键已存在的话，值不变，不存在则设置为默认值default的值
d1.setdefault(1,111)
d1.setdefault(8,8)
print "返回已存在1的值：",d1[1]
print "返回不存在的8的默认值：",d1[8]
#12、dict.update(dict2)，将dict2的键值对添加到dict字典的尾巴
print "输出d1的键值对：",d1
print "输出d2的键值对：",d2
d1.update(d2)
print "输出更新后的d1的键值对：",d1
#13、dict.values()返回字典中所有的值
print "返回d1所有的键：",d1.keys()
print "返回d1所有的值：",d1.values()
#14、dict.pop(key[,default])删除key及其值，并返回这个被删除的值
pop_ojb=d1.pop(1,000)
pop_ojb2=d1.pop('bcz',['bczdz'])
print "返回被删除的已存在1的值：",pop_ojb
print "返回删除不存在键的默认值：",pop_ojb2
print d1
#15、dict.popitem()随机删除任意键值对并以元组的形式返回该键值对
print "随机删除任意键值并返回：",d1.popitem()
print d1
#16、d=fromkeys(seq,value)，创建键为seq序列(可以是元祖、列表、字典)里面的元素，value为各键的初始值
